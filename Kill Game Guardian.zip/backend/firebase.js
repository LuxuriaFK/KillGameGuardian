const admin = require('firebase-admin');
const serviceAccount = require('./firebase/firebaseServiceAccountKey.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: 'https://seu-projeto-id.firebaseio.com'
});

const db = admin.firestore();
module.exports = db;
