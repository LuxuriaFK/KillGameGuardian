const express = require('express');
const db = require('./firebase.js');
const app = express();
const port = 3000;

app.use(express.json());

app.post('/report', async (req, res) => {
    const { ip, imei, device } = req.body;

    try {
        await db.collection('cheaters').add({
            ip,
            imei,
            device,
            timestamp: new Date()
        });
        console.log('Relatório salvo no Firebase:', { ip, imei, device });
        res.status(200).send({ status: 'salvo' });
    } catch (error) {
        console.error('Erro ao salvar no Firebase:', error);
        res.status(500).send({ error: 'erro interno' });
    }
});

app.listen(port, () => {
    console.log(`API AntiCheat com Firebase rodando na porta ${port}`);
});
