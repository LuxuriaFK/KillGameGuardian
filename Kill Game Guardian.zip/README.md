# AntiCheat Android + Firebase

Este projeto é uma solução completa de Anti-Cheat para aplicações Android, com integração de backend via Node.js e Firebase Firestore.

## Funcionalidades

### Aplicativo Android
- Detecta se o app Game Guardian (GG) está instalado ou executando, mesmo com nome/ícone alterados.
- Detecta o uso do modo flutuante (floating window) do Game Guardian.
- Bloqueia o acesso ao jogo caso o GG seja identificado.
- Encerra o jogo automaticamente se o GG for usado.
- Coleta dados do dispositivo suspeito:
  - IP
  - IMEI
  - Modelo do dispositivo
- Envia esses dados para o backend via API.

### Backend Node.js + Firebase
- API que recebe e registra os dados de usuários suspeitos.
- Salva os dados no Firestore, em uma coleção chamada `cheaters`.

## Estrutura

```
AntiCheatFullProject/
├── android/                  # Código-fonte Android
├── backend/                  # API Node.js com Firebase
├── firebase/                 # Chave de serviço do Firebase
└── README.md                 # Este arquivo
```

## Pré-requisitos

### Android
- Permissões necessárias:
  - `PACKAGE_USAGE_STATS`
  - `SYSTEM_ALERT_WINDOW`
  - `READ_PHONE_STATE`
- Adicione o serviço AntiCheat ao `AndroidManifest.xml`.

### Backend
1. Crie um projeto no [Firebase Console](https://console.firebase.google.com/)
2. Gere uma chave de serviço (`firebaseServiceAccountKey.json`) com permissão para o Firestore.
3. Substitua o conteúdo do arquivo `firebase/firebaseServiceAccountKey.json` com a sua chave real.
4. Instale as dependências:
```bash
cd backend
npm install
```

5. Execute a API:
```bash
node server.js
```

A API ficará escutando em `http://localhost:3000/report`

## Envio de dados do Android para o backend

No código do Android (`sendUserInfo`), você pode usar uma `HttpURLConnection` ou biblioteca como Retrofit/Volley para enviar os dados para a API.

Exemplo de payload:
```json
{
  "ip": "192.168.0.1",
  "imei": "123456789012345",
  "device": "Samsung Galaxy S21"
}
```

## Observações
- O envio real dos dados do Android está como `Log.i`, você deve trocar pela chamada HTTP para o endpoint `/report`.
- Você precisa configurar permissões no Firestore caso vá usar em produção.

## Licença
MIT
