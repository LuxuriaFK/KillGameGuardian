package com.seuapp.anticheat

import android.content.Context
import android.os.Build
import android.telephony.TelephonyManager

object DeviceUtils {
    fun getDeviceIMEI(context: Context): String {
        return try {
            val manager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                manager.imei ?: "N/A"
            } else {
                @Suppress("DEPRECATION")
                manager.deviceId ?: "N/A"
            }
        } catch (e: Exception) {
            "N/A"
        }
    }
}
