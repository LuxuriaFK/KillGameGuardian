package com.seuapp.anticheat

import java.net.*
import java.util.*

object NetworkUtils {
    fun getIPAddress(useIPv4: Boolean): String {
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (intf in interfaces) {
                val addrs = Collections.list(intf.inetAddresses)
                for (addr in addrs) {
                    if (!addr.isLoopbackAddress) {
                        val sAddr = addr.hostAddress ?: continue
                        val isIPv4 = sAddr.indexOf(':') < 0
                        if (useIPv4 && isIPv4) return sAddr
                        if (!useIPv4 && !isIPv4) {
                            val delim = sAddr.indexOf('%')
                            return if (delim < 0) sAddr.uppercase(Locale.getDefault())
                            else sAddr.substring(0, delim).uppercase(Locale.getDefault())
                        }
                    }
                }
            }
        } catch (ex: Exception) {}
        return ""
    }
}
