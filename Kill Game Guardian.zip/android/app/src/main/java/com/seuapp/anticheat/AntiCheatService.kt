package com.seuapp.anticheat

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.accessibility.AccessibilityManager
import android.app.usage.UsageStatsManager
import android.app.usage.UsageEvents
import java.util.*

class AntiCheatService : Service() {

    private val knownGGSignatures = listOf("com.gameguardian", "gameguardian", "gg", "guardian")

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Timer().scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                if (isGameGuardianRunning() || isFloatingViewActive()) {
                    blockAccess()
                }
            }
        }, 0, 5000)
        return START_STICKY
    }

    private fun isGameGuardianRunning(): Boolean {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val endTime = System.currentTimeMillis()
        val beginTime = endTime - 10000

        val usageEvents = usm.queryEvents(beginTime, endTime)
        val event = UsageEvents.Event()

        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event)
            knownGGSignatures.forEach {
                if (event.packageName?.contains(it, true) == true) {
                    Log.w("AntiCheat", "Game Guardian detectado: ${event.packageName}")
                    return true
                }
            }
        }
        return false
    }

    private fun isFloatingViewActive(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val list = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        return list.any { service ->
            service.resolveInfo.serviceInfo.packageName.contains("gameguardian", ignoreCase = true)
        }
    }

    private fun blockAccess() {
        Log.e("AntiCheat", "Bloqueio acionado")
        sendUserInfo()
        android.os.Process.killProcess(android.os.Process.myPid())
    }

    private fun sendUserInfo() {
        val ip = NetworkUtils.getIPAddress(true)
        val imei = DeviceUtils.getDeviceIMEI(this)
        val deviceModel = Build.MODEL
        val info = "IP: $ip
IMEI: $imei
Dispositivo: $deviceModel"
        Log.i("AntiCheat", "Usuário suspeito:
$info")
        // Aqui você pode enviar para um backend via API
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
